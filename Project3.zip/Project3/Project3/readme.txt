1) npm init -y

2)npm i express mongoose ejs
-ejs it's third party library, its part of node.js, its viewable part

3)connect your database with cmd
- new cmd promt
- cd \
- c:
- cd  C:\Program Files\MongoDB\Server\4.2\bin
- mongod.exe
- new cmd promt
- cd \
- c:
- cd  C:\Program Files\MongoDB\Server\4.2\bin
- mongo.exe

4)create new folder database 
- create file db.js

5)index.js
-require libraries like mongoose, express

6)connection code on database db.js file and index.js file
db();//function

7)var app = express();
app.use(express.json());

8)create new folder views
- create new file adduser.ejs
- create new file menu.ejs
- create new file showuser.ejs

use userdetails
db.createCollection("newusers");

db.newusers.insert([
    { "name" : "Anvita", "email":"anvita18@gmail.com", "mobileNo":9922557733},
{ "name" : "Nikita", "email":"nikita29@gmail.com", "mobileNo":9966887733},
{ "name" : "Siddhi", "email":"siddhi60@gmail.com", "mobileNo":7896557733}
]);

db.newUsers.find()

db.newUsers.find({"name":"Anvita"})


db.createCollection("products");
db.products.insert({ "name" : "shoes", "price":600, "discount":10});

app.use(express.urlencoded()); // if you are submiting your data trough form then this method is required 

app.use(express.json());// if you are submiting your data trough json format then this method is required

pw= elvp bvqf hlth jydz

npm install nodemailer // for sending mail